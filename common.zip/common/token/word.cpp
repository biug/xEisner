#include "word.h"

Token TWord::tokenizer = Token(1);
