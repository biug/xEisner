#include "pos.h"

Token TPOSTag::tokenizer = Token(1);
