#include "deplabel.h"

Token TDepLabel::tokenizer = Token(1);
