#include "emp.h"

Token TEmptyTag::tokenizer = Token(1);
